#!/usr/bin/env bash
# Прогоняет несколько случаев и сравнивает вывод.
set -u
BIN=./sortkit
# на Windows исполняемый файл называется sortkit.exe
if [ ! -x "$BIN" ] && [ -x ./sortkit.exe ]; then
    BIN=./sortkit.exe
fi
fail=0

check() {  # check <описание> <ожидаемое> <аргументы...>
    local desc="$1"
    local want="$2"
    shift 2
    local got
    got=$("$BIN" "$@" 2>&1)
    if [ "$got" = "$want" ]; then
        echo "  ok   $desc"
    else
        echo "  FAIL $desc"
        echo "       ожидалось: $want"
        echo "       получено:  $got"
        fail=1
    fi
}

check "по возрастанию"    "0 2 4"   "4 2 0"
check "по убыванию"       "4 2 0"   --desc "4 2 0"
check "вставками"         "0 2 4"   --algo=insertion "4 2 0"
check "один элемент"      "7"       "7"
check "уже отсортировано" "1 2 3"   "1 2 3"
check "отрицательные"     "-5 -1 3" "3 -5 -1"
check "три числа"         "1 5 9"   "9 1 5"

exit $fail
