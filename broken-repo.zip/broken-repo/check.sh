#!/usr/bin/env bash
# Проверяет, что репозиторий в порядке: ничего не брошено недоделанным,
# проект собирается, тесты проходят.
ok=1
fail() { echo "  [ ] $1"; ok=0; }
pass() { echo "  [x] $1"; }

if [ -z "$(git config user.email 2>/dev/null)" ]; then
    echo "  [!] не настроен автор коммитов: git config --global user.email you@example.com"
fi

[ -z "$(git status --porcelain)" ] && pass "рабочее дерево чистое" || fail "рабочее дерево не чистое"
[ -f .git/MERGE_HEAD ] && fail "merge не завершен" || pass "merge завершен"

# ветка может быть локальной, а может приехать из клона как origin/<имя>
resolve() {
    if git rev-parse --verify --quiet "refs/heads/$1" >/dev/null; then
        echo "refs/heads/$1"
    elif git rev-parse --verify --quiet "refs/remotes/origin/$1" >/dev/null; then
        echo "refs/remotes/origin/$1"
    fi
}

for b in main feature rescue; do
    [ -n "$(resolve "$b")" ] && pass "ветка $b есть" || fail "ветки $b нет"
done

HOT=$(resolve hotfix)
MAIN=$(resolve main)
if [ -n "$HOT" ] && [ -n "$MAIN" ] && git merge-base --is-ancestor "$HOT" "$MAIN"; then
    pass "merge доведен: hotfix влит в main"
else
    fail "hotfix не влит в main"
fi

git log --all --oneline | grep -q "вынес обмен в swap" && pass "первый коммит из feature на месте" || fail "потерян коммит 'feat: вынес обмен в swap'"
git log --all --oneline | grep -q "комментарии к сортировке" && pass "второй коммит из feature на месте" || fail "потерян коммит 'docs: комментарии к сортировке'"
git log --all --oneline | grep -q "защита от пустого массива" && pass "висящий коммит спасен" || fail "не найден коммит 'fix: защита от пустого массива'"

grep -q "debug: n=" src/main.c 2>/dev/null && fail "отладочный printf все еще в src/main.c" || pass "отладочный printf убран"
grep -q "<<<<<<<" src/sort.c 2>/dev/null && fail "в src/sort.c остались маркеры конфликта" || pass "маркеров конфликта нет"

# на Windows make часто называется mingw32-make
MAKE=""
if command -v make >/dev/null 2>&1; then
    MAKE=make
elif command -v mingw32-make >/dev/null 2>&1; then
    MAKE=mingw32-make
fi

if [ -n "$MAKE" ]; then
    if $MAKE -s >/dev/null 2>&1; then
        pass "проект собирается"
        if bash tests/run.sh >/dev/null 2>&1; then
            pass "тесты проходят"
        else
            fail "тесты не проходят (bash tests/run.sh покажет, какие)"
        fi
    else
        fail "проект не собирается ($MAKE)"
    fi
else
    echo "  [~] make не найден - сборка и тесты пропущены"
fi

echo
[ $ok -eq 1 ] && echo "ВСЕ НА МЕСТЕ" || echo "ЕСТЬ НЕРЕШЕННОЕ - см. список выше"
exit $((1-ok))
