#ifndef ARRAY_H
#define ARRAY_H

/* Разбирает строку "4 2 0" в массив. Возвращает число элементов или -1 при ошибке. */
int parse_numbers(const char *text, int **out);

/* Печатает массив через пробел и перевод строки. */
void print_numbers(const int *a, int n);

/* 1, если массив упорядочен по возрастанию (по убыванию при desc), иначе 0. */
int is_sorted(const int *a, int n, int desc);

#endif
