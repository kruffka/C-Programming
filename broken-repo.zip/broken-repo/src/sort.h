#ifndef SORT_H
#define SORT_H

typedef struct {
    long comparisons;
    long swaps;
} sort_stats;

void sort_bubble(int *a, int n, int desc, sort_stats *st);
void sort_insertion(int *a, int n, int desc, sort_stats *st);

#endif
