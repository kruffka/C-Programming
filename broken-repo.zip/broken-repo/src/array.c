#include "array.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

int parse_numbers(const char *text, int **out) {
    int cap = 8;
    int n = 0;
    int *a = malloc((size_t)cap * sizeof(*a));
    if (a == NULL) {
        return -1;
    }

    const char *p = text;
    while (*p != '\0') {
        while (isspace((unsigned char)*p)) {
            p++;
        }
        if (*p == '\0') {
            break;
        }

        char *end = NULL;
        long v = strtol(p, &end, 10);
        if (end == p) {
            free(a);
            return -1;
        }

        if (n == cap) {
            cap *= 2;
            int *tmp = realloc(a, (size_t)cap * sizeof(*a));
            if (tmp == NULL) {
                free(a);
                return -1;
            }
            a = tmp;
        }
        a[n++] = (int)v;
        p = end;
    }

    *out = a;
    return n;
}

void print_numbers(const int *a, int n) {
    for (int i = 0; i < n; i++) {
        if (i > 0) {
            putchar(' ');
        }
        printf("%d", a[i]);
    }
    putchar('\n');
}

int is_sorted(const int *a, int n, int desc) {
    for (int i = 1; i < n; i++) {
        if (desc ? (a[i - 1] < a[i]) : (a[i - 1] > a[i])) {
            return 0;
        }
    }
    return 1;
}
