#include "array.h"
#include "sort.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void usage(const char *prog) {
    printf("usage: %s [--desc] [--algo=bubble|insertion] [--stats] \"числа\"\n", prog);
}

int main(int argc, char **argv) {
    int desc = 0;
    int show_stats = 0;
    const char *algo = "bubble";
    const char *numbers = NULL;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--desc") == 0) {
            desc = 1;
        } else if (strcmp(argv[i], "--stats") == 0) {
            show_stats = 1;
        } else if (strncmp(argv[i], "--algo=", 7) == 0) {
            algo = argv[i] + 7;
        } else if (argv[i][0] == '-') {
            usage(argv[0]);
            return 2;
        } else {
            numbers = argv[i];
        }
    }

    if (numbers == NULL) {
        usage(argv[0]);
        return 2;
    }

    int *a = NULL;
    int n = parse_numbers(numbers, &a);
    if (n < 0) {
        fprintf(stderr, "не разобрал числа: %s\n", numbers);
        return 1;
    }

    printf("debug: n=%d\n", n);

    sort_stats st = {0, 0};
    if (strcmp(algo, "bubble") == 0) {
        sort_bubble(a, n, desc, &st);
    } else if (strcmp(algo, "insertion") == 0) {
        sort_insertion(a, n, desc, &st);
    } else {
        fprintf(stderr, "неизвестный алгоритм: %s\n", algo);
        free(a);
        return 2;
    }

    if (!is_sorted(a, n, desc)) {
        fprintf(stderr, "результат не упорядочен\n");
        free(a);
        return 3;
    }

    print_numbers(a, n);
    if (show_stats) {
        printf("comparisons: %ld, swaps: %ld\n", st.comparisons, st.swaps);
    }

    free(a);
    return 0;
}
