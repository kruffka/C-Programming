#include "sort.h"

/*
 * Сортировка обменом. На каждом проходе самый большой элемент всплывает
 * в конец, поэтому следующий проход можно делать короче.
 */
void sort_bubble(int *a, int n, int desc, sort_stats *st) {
    for (int i = 0; i < n - 1; i++) {
<<<<<<< HEAD
        for (int j = 0; j < n - 1; j++) {
=======
        for (int j = 0; j < n - i - 1 && n > 1; j++) {
>>>>>>> hotfix
            st->comparisons++;
            int need = desc ? (a[j] < a[j + 1]) : (a[j] > a[j + 1]);
            if (need) {
                int t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
                st->swaps++;
            }
        }
    }
}

/*
 * Сортировка вставками. Берем очередной элемент и ставим его на место
 * среди уже упорядоченных.
 */
void sort_insertion(int *a, int n, int desc, sort_stats *st) {
    for (int i = 1; i < n; i++) {
        int key = a[i];
        int j = i - 1;
        while (j >= 0) {
            st->comparisons++;
            if (desc ? (a[j] >= key) : (a[j] <= key)) {
                break;
            }
            a[j + 1] = a[j];
            st->swaps++;
            j--;
        }
        a[j + 1] = key;
    }
}
